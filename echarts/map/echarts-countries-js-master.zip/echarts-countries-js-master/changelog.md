# change log

# 1.0.4 - 23.02.2018

added word map from echarts
