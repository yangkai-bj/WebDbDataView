<!--
Paste your code here if you have a specific question.
-->
```js
var option = {
    series: [{
        type: 'liquidFill',
        data: [0.6]
    }]
};
```

<!--
Fork http://gallery.echartsjs.com/editor.html?c=xr1XplzB4e and reproduce your
problem, and paste the URL here to help us understand your question.
-->
