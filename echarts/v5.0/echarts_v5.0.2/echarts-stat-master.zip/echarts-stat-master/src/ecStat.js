define(function (require) {

    return {

        clustering: require('./clustering'),
        regression: require('./regression'),
        statistics: require('./statistics'),
        histogram: require('./histogram')

    };

});